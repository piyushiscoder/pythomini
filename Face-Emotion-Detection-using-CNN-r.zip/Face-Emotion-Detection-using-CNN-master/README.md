# Face-Emotion-Detection-using-CNN

 - Dataset- https://www.kaggle.com/c/challenges-in-representation-learning-facial-expression-recognition-challenge/data
 
 Built and trained a CNN model on aroud 24,000 images belonging to 5 classes - Angry, Happy, Neutral, Sad and Surprise. 
 <br/>
 
 Human face was detected from webcam using openCV and haarcascade_frontalface_alt. Face data was then given as input to trained model to give prediction in realtime.
 
